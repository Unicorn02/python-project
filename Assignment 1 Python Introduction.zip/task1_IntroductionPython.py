int_number = 5 #this is an integer data type
print(int_number) #displays the data type 
print(type(int_number))#print result 
print()
float_number = 5.4 #this is a float data type 
print(float_number)#print result 
print(type(float_number))#displays the data type 
print()
str_example = "these are my number" #this is a string data type
print(str_example)#print result
print(type(str_example))#displays the data type ==
print()
lst_numbers = [2,4,5,6] #this is a list in brackets
print(lst_numbers) #print result
print(type(lst_numbers))#displays the data type 
print()
trp_numbers = (2,4,5,6) #this is a tuple numbers in parantheses
print(trp_numbers)#print result
print(type(trp_numbers))#displays the data type 
print()
dict_number = {'one': 1, 'two':2, 'three':3} #this is a dictionary with key and value 
print(dict_number)#print result
print(type(dict_number))#displays the data type 
print()
print("ARITHMETIC OPERATORS")
sum_int_float = int_number + float_number # this add both variale numbers 
print("This is an addition: ", (sum_int_float)) #print result

substr_diff = int_number - 2 #this subtract 2 from the int_number
print("This is a substration: ", (substr_diff))#print result

multip_product = int_number * 2
print("This is the Multiplication: ", (multip_product))

divis_quotient = int_number / 2
print("This is the Division: ", (divis_quotient))
print()
print("COMPARISON OPERATORS")
is_equal = int_number == 8 #this shows true or false statement
print("this is equal comparison: ", (is_equal))
is_not_equal = int_number != 8  #this shows boolean true or false statement
print("this is not equal comparison: ", (is_not_equal))
is_greater= int_number > 8  #this shows boolean true or false statement
print("this is greater comparison: ", (is_greater))
is_less= int_number < 8  #this shows boolean true or false statement
print("this is less greater comparison: ", (is_less))
print()
print("LOGICAL OPERATORS")
and_oper = int_number == 8 and int_number> 8 #this shows a boolean true or false statement
print("this is the - and - logical operator: ", (and_oper))#print the resutt
or_oper = int_number < 8 or int_number!= 8 #this shows a boolean true or false statement
print("this is the - or - logical operator: ", (or_oper))#print result
not_oper = not(is_equal)  #this shows a boolean true or false statement
print("this is the - not - logical operator: ", (not_oper))#print result
