# create the base class parent flowers with method “show” to overridden by subclasses which has the –init—methods decalred within the class 
class Flowers:
    def __init__(self, name):
        self.name = name
#passing the argument using “self”
    def show(self):
        raise NotImplementedError("Subclass must implement abstract method")

#create the child class or subclass Rose which inherit from class flowers 
class Rose(Flowers):
    def show(self):
        return f"{self.name} says Wow!"

#create the child class or subclass Orchid which inherit from class flowers 
class Orchid(Flowers):
    def show(self):
        return f"{self.name} says Uhh!"

#objects rose and orchid are instances, which demonstrate polymorphism through the “show” method 
rose = Rose("Blossom")
orchid = Orchid("Openes")

print(rose.show())  
print(orchid.show())  


