# this allow access to system-specific parameter and function.
import sys

# Username and password check
for i in range(3):
    user = input("Enter your username: ")
    pwd = input("Enter your password: ")
    if user == "Admin" and pwd == "Student1":
        print("Welcome to the Store!")
        break
    else:
        print("Incorrect Password! Try again")
else:
    print("You have reached your attempt limit. Goodbye!")
    sys.exit(1)

# Prompt user for name
name = input("What is your name: ")
print(f"Your name has {len(name)} characters.")
print("Welcome to our store, ", name, "!")

# Prompt for age until user is 18 or older
while True:
    age = int(input("How old are you: "))
    if age >= 18:
        print("You can buy alcohol and cigarettes.")
        alcohol_cost = 1.50
        cigarette_cost = 3.40
        total_cost = alcohol_cost + cigarette_cost
        print("The total cost is: £", total_cost)
        break
    else:
        print("Sorry, you are too young to purchase these items!")
    break
# Prompt user to enter other items
response = input("Would you like to enter other items? (yes/no): ")
if response.lower() == "yes":
    print("Let's add and calculate other items: ")
    num1 = float(input("Enter the first item's cost (£): "))
    num2 = float(input("Enter the second item's cost (£): "))
    opr = input("Enter the operation (+, -, *, /): ")
    if opr == "*":
        print("Total cost is: £", num1 * num2)
    elif opr == "+":
        print("Total cost is: £", num1 + num2)
    elif opr == "-":
        print("Total cost is: £", num1 - num2)
    elif opr == "/":
        if num2 != 0:
            print("Total cost is: £", num1 / num2)
        else:
            print("Error: Division by zero")
    else:
        print("Sorry, this is an incorrect entry!")
else:
    print("Thank you for shopping with us. Goodbye!")
