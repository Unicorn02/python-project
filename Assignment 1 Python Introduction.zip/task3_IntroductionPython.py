# we call numpy library with it module math used for area circle calculation 
import numpy
import math

#this function is to calculate the area of a circle by using radius and pi
def area_circle(radius):
    return math.pi * radius * radius

# this is a function that return a formatted string
def numberEvenorOdd(number):
    return "even" if number % 2 == 0 else "odd"

#this function return the message with the radius unit and the message whether the result is odd or even
def message(radius, area_circle):
    result_type = numberEvenorOdd(area_circle)
    return f"The area of a circle with radius {radius:.2f} units is {area_circle:.2f} square units. It's an {result_type} number."

#the variable are created to input the radius size number
radius = float(input("Enter a number: "))
#the variable for area is created to start the calculation using the function area_circle
area = area_circle(radius)
#the message displays the result as either odd or even 
result = message(radius, area)
print(result)

