#the import of module math is to make calculation and datetime to display the current date/time
import math 
import datetime 
import sys 

#check if the correct number of command line are provided 
if len(sys.argv) != 3:
   print (“Usage: python hypotenuse_ calculator.py <length of side a> < length of side b>”)
   sys.exit(1)

#the now variable is create using the unction now to display current date/time
now = datetime.datetime.now()
#date/time displays using the string format
print (f"Today's date and time is, {now.strftime('%Y-%m-%d  %H:%M:%S')}.")

#the user input their full name
fullName = input("Enter your full name: ")
print(f"Hi {fullName}, please enter the lengh of sides below to calculate right triangle Hypotenuse: ")

#the variable is created to enter the length of each side in order to calculate the hypotenuse
try:
a = float(input ("Enter the lengh of side 'a': "))
b = float(input("Enter the lengh of side 'b': "))
except  ValueError:
 	sys.exit(1)

hypotenuse = math.sqrt(a**2 + b**2)
print(f"The hypotenuse of the right triangle is {hypotenuse:.2f} cm")


